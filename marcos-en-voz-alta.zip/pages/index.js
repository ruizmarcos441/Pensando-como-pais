import { useState } from 'react';

export default function Home() {
  return (
    <main style={{ padding: '2rem', fontFamily: 'Arial, sans-serif', maxWidth: '800px', margin: 'auto' }}>
      <h1 style={{ fontSize: '2.5rem' }}>Marcos en Voz Alta</h1>
      <p>Ideas para un país más justo. Reflexiones desde la juventud, el derecho y la política.</p>
      <section style={{ marginTop: '2rem' }}>
        <h2>Sobre mí</h2>
        <p>Soy Marcos Antonio Menjívar Ruiz, abogado, docente y apasionado por el derecho penal, la democracia y los derechos humanos.</p>
      </section>
      <section style={{ marginTop: '2rem' }}>
        <h2>Suscribite por correo</h2>
        <input type="email" placeholder="Tu correo electrónico" style={{ padding: '0.5rem', width: '60%' }} />
        <button style={{ padding: '0.5rem', marginLeft: '0.5rem' }}>Suscribirme</button>
      </section>
      <section style={{ marginTop: '2rem' }}>
        <h2>Podcast (Próximamente)</h2>
        <p>Estoy trabajando en una serie de episodios sobre temas actuales del país, entrevistas y reflexiones personales. ¡Muy pronto en Spotify!</p>
      </section>
      <section style={{ marginTop: '2rem' }}>
        <h2>Contacto</h2>
        <p>Podés escribirme a <a href="mailto:marcosvozalta@gmail.com">marcosvozalta@gmail.com</a> o seguirme en Instagram: <strong>@marcosvozalta</strong>.</p>
      </section>
    </main>
  );
}